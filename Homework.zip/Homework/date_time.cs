using System;

class date_time
{
    static void Main(string[] args)
    {
        DateTime date = DateTime.Now;
        Console.WriteLine(":::: Date & Time :::: \n"+date);
    }
}